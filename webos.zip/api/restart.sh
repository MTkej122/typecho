#!/bin/bash
kill -9 `cat pidfile.txt`
ps -ef|grep webos.jar|grep -v grep|awk '{system("echo "$2";kill -9 "$2)}'
nohup java -javaagent:webos.jar="-frame true" -XX:+UseG1GC -Xms128m -Xmx256m -jar webos.jar > webos.log &
echo '正在启动...'
sleep 3
cat webos.log
